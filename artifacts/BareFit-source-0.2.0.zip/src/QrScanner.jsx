import React, {useEffect,useRef,useState} from 'react';
import {Camera,ImagePlus} from 'lucide-react';
import jsQR from 'jsqr';
import {parsePairQr} from '../shared/pairing.mjs';

export default function QrScanner({onScan}) {
  const video=useRef(null), stream=useRef(null), timer=useRef(null), found=useRef(false), alive=useRef(true);
  const [error,setError]=useState(''), [active,setActive]=useState(false), [busy,setBusy]=useState(false);
  const live=window.isSecureContext && !!navigator.mediaDevices?.getUserMedia;
  const stop=()=>{clearTimeout(timer.current);stream.current?.getTracks().forEach(t=>t.stop());stream.current=null;};
  useEffect(()=>()=>{alive.current=false;stop();},[]);
  const accept=(text)=>{
    const parsed=parsePairQr(text);
    if(found.current)return;
    found.current=true;stop();setActive(false);onScan(parsed);
  };
  const decode=(source,width,height)=>{
    const scale=Math.min(1,1200/Math.max(width,height));
    const canvas=document.createElement('canvas');canvas.width=Math.round(width*scale);canvas.height=Math.round(height*scale);
    const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(source,0,0,canvas.width,canvas.height);
    const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);
    return jsQR(pixels.data,pixels.width,pixels.height,{inversionAttempts:'attemptBoth'})?.data;
  };
  const start=async()=>{
    setError('');setBusy(true);found.current=false;
    try {
      const media=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:'environment'},width:{ideal:1280}}});
      if(!alive.current){media.getTracks().forEach(t=>t.stop());return;}
      stream.current=media;video.current.srcObject=media;await video.current.play();setActive(true);
      const tick=()=>{
        if(!alive.current||found.current||!stream.current)return;
        try {
          const v=video.current;
          if(v.readyState>=2&&v.videoWidth){const text=decode(v,v.videoWidth,v.videoHeight);if(text){accept(text);return;}}
        } catch(e){setError(e.message);}
        timer.current=setTimeout(tick,220);
      };tick();
    } catch(e) {
      stop();setError(e.name==='NotAllowedError'?'הגישה למצלמה לא אושרה. אפשר לצלם או לבחור תמונת QR.':'המצלמה אינה זמינה. אפשר לצלם או לבחור תמונת QR.');
    } finally {if(alive.current)setBusy(false);}
  };
  const fromFile=async(e)=>{
    const file=e.target.files?.[0];e.target.value='';if(!file)return;
    stop();setActive(false);setError('');setBusy(true);found.current=false;
    let url;
    try {
      if(file.size>20000000)throw Error('בחרו תמונה קטנה מ־20MB');
      url=URL.createObjectURL(file);const img=new Image();
      await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(Error('לא ניתן לקרוא את התמונה. נסו לצלם שוב.'));img.src=url;});
      if(!alive.current)return;
      const text=decode(img,img.naturalWidth,img.naturalHeight);
      if(!text)throw Error('לא נמצא QR בתמונה. צלמו מקרוב את כל הריבוע, ללא השתקפות.');
      accept(text);
    }catch(e){if(alive.current)setError(e.message);}
    finally{if(url)URL.revokeObjectURL(url);if(alive.current)setBusy(false);}
  };
  return <div className="qr-scanner">
    <p>כוונו אל קוד ה־QR שבמסך האימון. פרטי החיבור יתמלאו אוטומטית.</p>
    <video ref={video} autoPlay playsInline muted className={active?'scanner-video':'scanner-video inactive'} />
    {live?<button className="action primary" onClick={start} disabled={busy||active}><Camera size={22}/>{busy?'פותח מצלמה…':'פתיחת מצלמה'}</button>
      :<p className="muted">בחיבור המקומי הזה הסריקה נעשית מצילום. לחצו על המצלמה וצלמו את הקוד.</p>}
    <div className="scanner-options">
      <label className="action"><Camera size={22}/>צילום קוד QR<input aria-label="צילום קוד QR" type="file" accept="image/*" capture="environment" onChange={fromFile} disabled={busy}/></label>
      <label className="action"><ImagePlus size={22}/>בחירת תמונת QR<input aria-label="בחירת תמונת QR" type="file" accept="image/*" onChange={fromFile} disabled={busy}/></label>
    </div>
    {busy&&<p role="status">קורא את הקוד…</p>}
    {error&&<p className="warning" role="alert">{error}</p>}
    <p className="muted">התמונה מפוענחת בטלפון ואינה נשלחת לשרת. אחרי הסריקה יש לאשר את החיבור במסך האימון.</p>
  </div>;
}
