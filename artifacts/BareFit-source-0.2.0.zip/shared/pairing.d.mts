export function parsePairQr(raw: string): {base:string;room:string;code:string};
