# Verification — 23 October 2026

## Passed

- 13 automated tests: monotonic catch-up over missed callbacks; millisecond pause/resume; final round and set transitions; finish/restart; safe paused recovery; invalid settings/snapshots; manual phase navigation; running-workout mutation rejection; custom sequences; boundary formatting; 24-hour simulated reference-clock comparison; pairing approval, single controller/viewer permissions, duplicate/out-of-order command rejection, reconnect and revocation; cross-origin request rejection.
- Web production build with modern and legacy JavaScript bundles and locally bundled assets/fonts.
- Native TypeScript check.
- Hermes JavaScript bundle export for Android and iOS using React Native TV. This verifies module resolution and bundle generation, not iOS/tvOS compilation or device operation.
- Android TV release-variant APK build, API 24 minimum, API 36 target, ARM64/ARMv7/x86/x86_64. Uses a development signing key. APK contains JavaScript, fonts and background assets and TV launcher metadata/banner.
- Separate Android phone release-variant APK build with package `com.barefit.timer` and unspecified orientation. Uses the same shared core and includes both controller and local-timer modes. Also development-signed; not physically device-tested.
- LG webOS IPK packaging with the official `@webos-tools/cli`.
- Browser UI verification: actual start/pause; QR and one-time connection request; approval on display; controller receives current state; remote next-phase changes both screens; refresh while running restores paused state with time preserved.
- Visual inspection of main display and a 390 × 844 CSS-pixel phone viewport. Screenshots are in `artifacts/`.

## Not yet verified / release work

- No physical Android TV, Apple TV, Samsung, LG, iPhone or Android phone was tested. No hardware-level stability or timing guarantee is claimed.
- iOS/tvOS native compilation and signing require macOS, Xcode and an appropriate signing identity. Windows prebuild explicitly refused the iOS native target. No IPA is supplied.
- Samsung source package requires Tizen Studio, a Samsung signing certificate, WGT build and testing on a specific TV. No signed WGT is supplied.
- Android APKs are for internal testing, signed with a development key. Store release signing, app-store review and installed-device validation are outstanding.
- Production TLS, credential storage hardening, real network latency measurements, physical 8/24-hour endurance and studio readability tests remain release acceptance work.
- Native program import/export and a visual complex-sequence editor are not yet implemented; Web supports JSON import/export and the shared engine supports custom sequences.

The bundled source intentionally excludes local pairing credentials and build-network workarounds. A temporary per-process DNS/CONNECT workaround was used during dependency downloads; it did not change OS DNS or disable certificate validation.


## Hall visibility and coach audio update

- 24 automated tests pass, including regular/rest 3-second counts, final-work 10-second counts, silent rest-start narration with its own tone, multi-set last-round distinction, AMRAP/single-effort exclusion, pause/stop cancellation, skipped callbacks, and PCM asset durations.
- Hebrew 3 and 6 regenerated with pointed text, normal speaking rate and sibilant-preserving audio trim; under one second each. The voice is synthetic Microsoft Asaf, not a human coach recording. Studio speaker intelligibility still requires listening in the room.
- Shared native logic passes TypeScript. Updated Web production and Tizen/webOS source directories include the audio assets. Existing 0.1.0 APK/IPK/ZIP downloads were created before this change and are not updated installers.
- Hall mode has large white digits, subdued background and phase colors in the applicable final 3 or 10 seconds. The original circular design remains available.
- Very short final rounds prioritize the final-round announcement at entry, then speak the current remaining seconds. No delayed numbers are queued.
- Research: https://smartwod.app/wod-timer and https://www.intervaltimer.com/help/settings/sound-settings?platform=android informed visibility, voice cues and independent volume controls.


## Phone builder and QR — 0.2.0

- 27 automated tests passed, including QR image encode/decode roundtrip, strict payload validation and advertised studio URL.
- Browser end-to-end: created a custom 30-second / 4-round workout without a host connection; reloaded; scanned a real generated QR image through the file picker; host received request; host approved; phone became controller; saved workout sent to the host and both screens showed 00:30 / 1 of 4.
- Checked 390px phone layout and HTTP photo-capture fallback. No physical phone camera tested; live native camera requires on-device validation.
- Android phone APK 0.2.0 (versionCode 2), all four architectures, release variant with development signing, built successfully. Manifest requests camera, removes audio-recording permission and makes camera hardware optional. Includes updated audio assets and QR scanning.
- iOS Hermes export succeeded with expo-camera; this is not iOS native compilation/signing.
- TV builds resolve PhoneScanner.tv.tsx and tvOS prebuild excludes the phone-only ExpoCamera pod.
- Phone APK downloadable through local server. Existing 0.1.0 TV installers remain older artifacts.
