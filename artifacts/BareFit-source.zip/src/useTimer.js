import { useEffect, useRef, useState } from "react";
import { WorkoutEngine } from "../shared/engine.mjs";
import { Connection, request } from "../shared/connection.mjs";
import { read, write } from "./storage";
export function useTimer(base) {
  const engine = useRef(null);
  if (!engine.current) {
    engine.current = new WorkoutEngine();
    const data = read("session", null);
    if (data)
      try {
        engine.current.restore(data);
      } catch {
        write("recovery-warning", true);
      }
  }
  const [view, setView] = useState(() => engine.current.view());
  const processed = useRef(null);
  if (!processed.current) processed.current = read("session", {})?.processed || [];
  const [connection, setConnection] = useState("disconnected");
  const [code, setCode] = useState(null);
  const [pending, setPending] = useState([]);
  const [devices, setDevices] = useState([]);
  const [error, setError] = useState("");
  const link = useRef(null);
  const [muted, setMuted] = useState(() => read("muted", false));
  const audio = useRef(null);
  const mutedRef = useRef(muted);
  mutedRef.current = muted;
  const lastSound = useRef("");
  const [volume, setVolume] = useState(() => read("volume", 0.6));
  const volumeRef = useRef(volume);
  volumeRef.current = volume;
  const unlock = () => {
    try {
      const Context = window.AudioContext || window.webkitAudioContext;
      if (!audio.current && Context) audio.current = new Context();
      audio.current?.resume();
    } catch {}
  };
  const beep = (frequency, duration = 0.12) => {
    if (mutedRef.current || volumeRef.current === 0 || !audio.current || audio.current.state !== "running")
      return;
    const ctx = audio.current,
      o = ctx.createOscillator(),
      g = ctx.createGain();
    o.frequency.value = frequency;
    g.gain.setValueAtTime(volumeRef.current * 0.15, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    o.connect(g);
    g.connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + duration);
    o.onended = () => { o.disconnect(); g.disconnect(); };
  };
  const persist = () => {
    const saved = write("session", {...engine.current.snapshot(), processed: processed.current});
    if (!saved)
      setError("לא ניתן לשמור במכשיר. האימון ממשיך, אך שחזור אינו זמין.");
    return saved;
  };
  const execute = (type, payload, deferPersist = false) => {
    unlock();
    try {
      if (type === "SET_VOLUME") {
        const value = Number(payload);
        if (!Number.isFinite(value) || value < 0 || value > 1)
          throw Error("עוצמה לא תקינה");
        setVolume(value);
        write("volume", value);
      } else engine.current.command(type, payload);
      if (!deferPersist) persist();
      const v = engine.current.view();
      setView(v);
      link.current?.send({ type: "state", state: v });
      return true;
    } catch (e) {
      setError(e.message);
      return false;
    }
  };
  const executeRef = useRef(execute);
  executeRef.current = execute;
  useEffect(() => {
    let count = 0;
    let lastRevision = -1;
    const timer = setInterval(() => {
      const v = engine.current.view();
      setView(v);
      count++;
      if (v.revision !== lastRevision || count % 10 === 0) {
        persist();
        lastRevision = v.revision;
      }
      if (count % 3 === 0) link.current?.send({ type: "state", state: v });
      const sec = Math.ceil(v.remaining / 1000);
      const sound = `${v.index}:${sec}:${v.status}`;
      if (v.status === "running" && sound !== lastSound.current) {
        if (sec <= 3 && sec > 0) beep(650);
        else if (v.remaining >= v.duration - 150)
          beep(v.phase === "work" ? 1100 : 450, 0.3);
      }
      if (v.status === "finished" && lastSound.current !== sound)
        beep(1300, 0.7);
      lastSound.current = sound;
    }, 100);
    const hide = () => persist();
    window.addEventListener("pagehide", hide);
    return () => {
      clearInterval(timer);
      window.removeEventListener("pagehide", hide);
    };
  }, []);
  useEffect(() => {
    let cancelled = false;
    let conn;
    let retry;
    setCode(null);
    setPending([]);
    setDevices([]);
    const connect = async () => {
      try {
        let credentials = read("host:" + base, null);
        if (!credentials) {
          credentials = await request(base, "/api/rooms", {});
          write("host:" + base, credentials);
        }
        if (cancelled) return;
        conn = new Connection(
          base,
          { ...credentials, role: "host" },
          (m) => {
            if (m.type === "authenticated") {
              setDevices(m.devices || []);
              conn.send({ type: "state", state: engine.current.view() });
            }
            if (m.type === "pair-code") setCode(m);
            if (m.type === "pair-request") {
              setCode(null);
              setPending((p) => (p.some((x) => x.id === m.id) ? p : [...p, m]));
            }
            if (m.type === "devices") setDevices(m.devices);
            if (m.type === "error") setError(m.error);
            if (m.type === "command") {
              const seen = processed.current;
              const previous = seen.find((x) => x.id === m.id);
              if (previous) {
                conn.send(previous);
                return;
              }
              const ok = executeRef.current(m.command, m.payload, true);
              const ack = {
                type: "ack",
                id: m.id,
                ok,
                error: ok ? "" : "לא ניתן לבצע את הפקודה במצב הנוכחי",
              };
              processed.current = [...seen, ack].slice(-500);
              if (!persist()) { ack.ok = false; ack.error = 'הפעולה בוצעה אך שמירת המצב נכשלה'; }
              conn.send(ack);
            }
          },
          setConnection,
        );
        link.current = conn;
      } catch (e) {
        if (!cancelled) {
          setConnection("disconnected");
          setError("הטיימר זמין. לחיבור טלפון יש להפעיל את שירות הסטודיו.");
          retry = setTimeout(connect, 5000);
        }
      }
    };
    connect();
    return () => {
      cancelled = true;
      clearTimeout(retry);
      conn?.close();
      link.current = null;
    };
  }, [base]);
  useEffect(() => {
    let lock;
    const acquire = () => {
      if (view.status === "running" && document.visibilityState === "visible")
        navigator.wakeLock
          ?.request("screen")
          .then((l) => (lock = l))
          .catch(() => {});
    };
    acquire();
    document.addEventListener("visibilitychange", acquire);
    return () => {
      lock?.release();
      document.removeEventListener("visibilitychange", acquire);
    };
  }, [view.status]);
  return {
    view,
    execute,
    connection,
    code,
    pending,
    devices,
    error,
    setError,
    muted,
    toggleMute: () => {
      unlock();
      setMuted((v) => {
        write("muted", !v);
        return !v;
      });
    },
    volume,
    newCode: () => link.current?.send({ type: "new-code" }),
    approve: (id, approved) => {
      link.current?.send({ type: approved ? "approve" : "reject", id });
      setPending((p) => p.filter((x) => x.id !== id));
    },
    revoke: (id) => link.current?.send({ type: "revoke", id }),
    resetPairing: () => {
      write("host:" + base, null);
      location.reload();
    },
  };
}
