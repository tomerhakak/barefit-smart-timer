import React, { useState, useEffect, useRef } from "react";
import {
  Play,
  Pause,
  Square,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Smartphone,
  SlidersHorizontal,
  X,
  Plus,
  Check,
  ArrowLeft,
  Wifi,
  WifiOff,
  Download,
  Upload,
  RotateCcw,
  Monitor,
  BookOpen,
  ChevronLeft,
} from "lucide-react";
import QRCode from "qrcode";
import {
  PRESETS,
  LABELS,
  formatTime,
  validateWorkout,
} from "../shared/engine.mjs";
import { Connection, request, commandId } from "../shared/connection.mjs";
import { useTimer } from "./useTimer";
import { read, write } from "./storage";
const palette = {
  ready: "#b4ff00",
  prepare: "#57b7ff",
  work: "#b4ff00",
  rest: "#ffb146",
  between: "#ffb146",
  finished: "#b4ff00",
};
export default function App() {
  const params = new URLSearchParams(location.search);
  return params.get("mode") === "coach" ||
    location.pathname.endsWith("/coach") ? (
    <Coach />
  ) : (
    <Display />
  );
}
function Brand({ small = false }) {
  return (
    <div className={"brand " + (small ? "small" : "")} dir="ltr">
      <img src="./icon.svg" alt="" />
      <strong>Barefit</strong>
    </div>
  );
}
function Button({ icon: Icon, children, primary = false, ...props }) {
  return (
    <button className={"action " + (primary ? "primary" : "")} {...props}>
      {Icon && <Icon />}
      {children && <span>{children}</span>}
    </button>
  );
}
function Overlay({ title, onClose, children, wide = false }) {
  const ref = useRef(null);
  useEffect(() => {
    const prev = document.activeElement;
    ref.current?.querySelector("button")?.focus();
    const handler = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab") {
        const els = ref.current.querySelectorAll(
          "button:not(:disabled),input,select,a[href],textarea",
        );
        const first = els[0],
          last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener("keydown", handler);
    return () => {
      document.removeEventListener("keydown", handler);
      prev?.focus();
    };
  }, []);
  return (
    <div
      className="scrim"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <section
        ref={ref}
        className={"dialog " + (wide ? "wide" : "")}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <header>
          <h2>{title}</h2>
          <button className="icon-button" onClick={onClose} aria-label="סגירה">
            <X />
          </button>
        </header>
        {children}
      </section>
    </div>
  );
}
function TimerFace({ view, compact = false }) {
  const shown =
    view.status === "ready" ? view.workout.work * 1000 : view.remaining;
  return (
    <div
      className={"timer-face " + (compact ? "compact" : "")}
      style={{ "--phase": palette[view.phase] || palette.work }}
    >
      <svg className="ring" viewBox="0 0 600 600" aria-hidden="true">
        <circle className="ring-outline" cx="300" cy="300" r="289" />
        <circle className="ring-track" cx="300" cy="300" r="271" />
        <circle
          className="ring-progress"
          cx="300"
          cy="300"
          r="271"
          pathLength="100"
          strokeDasharray={`${view.status === "ready" ? 100 : view.progress * 100} 100`}
        />
      </svg>
      <div className="timer-inner">
        <div className="phase-label">
          {view.status === "paused"
            ? "השהיה"
            : view.label || LABELS[view.phase]}
        </div>
        <div
          className="clock"
          dir="ltr"
          aria-label={`${LABELS[view.phase]} ${formatTime(shown)}`}
        >
          {view.status === "finished" ? "✓" : formatTime(shown)}
        </div>
        <div className="round-badge">
          <span>{view.status === "finished" ? "הושלם" : "סבב"}</span>
          <strong dir="ltr">
            {view.status === "finished" ? view.workout.rounds : view.round}
            <i>/{view.workout.rounds}</i>
          </strong>
        </div>
        {view.workout.sets > 1 && (
          <div className="set-label">
            סט {view.set} מתוך {view.workout.sets}
          </div>
        )}
      </div>
    </div>
  );
}
function Controls({ view, execute, stop }) {
  return (
    <div className="controls" dir="ltr">
      <Button icon={SkipForward} onClick={() => execute("NEXT_PHASE")}>
        דלג קדימה
      </Button>
      <Button
        primary
        icon={view.status === "running" ? Pause : Play}
        onClick={() => execute(view.status === "running" ? "PAUSE" : "START")}
      >
        {view.status === "running"
          ? "השהיה"
          : view.status === "paused"
            ? "המשך"
            : view.status === "finished"
              ? "אימון נוסף"
              : "התחל אימון"}
      </Button>
      <Button icon={Square} onClick={stop} disabled={view.status === "ready"}>
        עצור
      </Button>
    </div>
  );
}
function useBase() {
  return useState(() =>
    read("hub", location.protocol.startsWith("http") ? location.origin : ""),
  );
}
function Display() {
  const [base, setBase] = useBase();
  const t = useTimer(base);
  const [panel, setPanel] = useState(null),
    [fullscreen, setFullscreen] = useState(false),
    [clean, setClean] = useState(() => read("clean", false)),
    [qr, setQr] = useState("");
  const [now, setNow] = useState(Date.now());
  const [programs, setPrograms] = useState(() => read("programs", PRESETS));
  const [stateTip, setStateTip] = useState(
    read("session", null)?.status === "running"
      ? "האימון שוחזר בהשהיה. אפשר להמשיך כשמוכנים."
      : "",
  );
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const pairUrl = t.code
    ? `${base}/?mode=coach#room=${t.code.room}&code=${t.code.code}`
    : "";
  useEffect(() => {
    if (pairUrl)
      QRCode.toDataURL(pairUrl, {
        margin: 2,
        width: 256,
        color: { dark: "#0d1207", light: "#ffffff" },
      }).then(setQr);
  }, [pairUrl]);
  useEffect(() => {
    const handle = (e) => {
      if (["INPUT", "SELECT", "TEXTAREA"].includes(e.target.tagName)) return;
      const modal = document.querySelector("[role=dialog]");
      if (["ArrowRight", "ArrowLeft", "ArrowDown", "ArrowUp"].includes(e.key)) {
        const elements = Array.from(
          (modal || document).querySelectorAll("button:not(:disabled),a[href]"),
        ).filter((el) => el.offsetParent !== null);
        const current = elements.indexOf(document.activeElement);
        const delta = ["ArrowRight", "ArrowDown"].includes(e.key) ? 1 : -1;
        elements[
          (current + delta + elements.length) % elements.length
        ]?.focus();
        e.preventDefault();
      } else if (!modal && [" ", "MediaPlayPause"].includes(e.key)) {
        e.preventDefault();
        t.execute(t.view.status === "running" ? "PAUSE" : "START");
      } else if (!modal && e.key === "MediaStop") setPanel("stop");
    };
    document.addEventListener("keydown", handle);
    return () => document.removeEventListener("keydown", handle);
  }, [t.view.status]);
  useEffect(() => {
    const handler = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handler);
    return () => document.removeEventListener("fullscreenchange", handler);
  }, []);
  const full = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      t.setError("מסך מלא אינו זמין בדפדפן זה");
    }
  };
  const savePrograms = (p) => {
    setPrograms(p);
    if (!write("programs", p)) t.setError("שמירת התוכניות נכשלה");
  };
  return (
    <main
      className={"display " + (clean ? "clean" : "")}
      style={{ "--phase": palette[t.view.phase] || palette.work }}
    >
      <div className="photo" />
      <div className="photo-shade" />
      <header className="topbar">
        <div className="brand-block">
          <Brand />
          <p dir="ltr">
            STRONGER PEOPLE
            <br />
            HAPPIER LIVES
            <span />
          </p>
        </div>
        <nav>
          <button onClick={() => setPanel("library")}>
            <BookOpen size={18} /> ספריית אימונים
          </button>
          <button
            onClick={() => {
              setPanel("pair");
              t.newCode();
            }}
          >
            <Smartphone size={18} /> חיבור מאמן{" "}
            <span
              className={
                "status-dot " + (t.connection === "connected" ? "online" : "")
              }
            />
          </button>
          <button
            className="icon-button"
            onClick={() => setPanel("settings")}
            aria-label="הגדרות"
          >
            <SlidersHorizontal size={19} />
          </button>
        </nav>
      </header>
      <aside className="workout-info">
        <span className="eyebrow">האימון שלכם</span>
        <h1>{t.view.workout.name}</h1>
        <div className="workout-facts">
          <span>
            <strong>{t.view.workout.work}</strong>שניות עבודה
          </span>
          <span>
            <strong>{t.view.workout.rest}</strong>שניות מנוחה
          </span>
        </div>
        <div className="workout-divider" />
        <p>
          <span>{t.view.workout.rounds} סבבים</span>
          <span>×</span>
          <span>{t.view.workout.sets} סטים</span>
        </p>
        <button className="text-button" onClick={() => setPanel("library")}>
          החלפת אימון <ChevronLeft size={16} />
        </button>
      </aside>
      <section className="timer-stage" aria-label="שעון אימון">
        <TimerFace view={t.view} />
        <Controls
          view={t.view}
          execute={t.execute}
          stop={() => setPanel("stop")}
        />
        <div className="under-controls">
          {t.view.status === "ready"
            ? "קחו נשימה. מתחילים כשאתם מוכנים."
            : t.view.status === "paused"
              ? "הזמן עוצר. הכוח נשאר."
              : t.view.status === "finished"
                ? "נתתם הכול. נתראה באימון הבא."
                : `עוד ${formatTime(t.view.totalRemaining)} עד לסיום האימון`}
        </div>
      </section>
      <footer className="display-footer">
        <div className="footer-left">
          <span className="studio-dot" /> BAREFIT STUDIO{" "}
          <span className="subtle">/</span> SMART TIMER
        </div>
        <div className="footer-actions">
          <button
            className="icon-button"
            onClick={t.toggleMute}
            aria-label={t.muted ? "הפעלת צליל" : "השתקת צליל"}
          >
            {t.muted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
          <button className="icon-button" onClick={full} aria-label="מסך מלא">
            {fullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
          </button>
        </div>
      </footer>
      {(t.error || stateTip) && (
        <div className="toast" role="status">
          <span>{t.error || stateTip}</span>
          <button
            onClick={() => {
              t.setError("");
              setStateTip("");
            }}
            aria-label="סגירת הודעה"
          >
            <X size={17} />
          </button>
        </div>
      )}
      {panel === "stop" && (
        <Overlay title="לעצור את האימון?" onClose={() => setPanel(null)}>
          <p>השעון יחזור להתחלה. התוכנית השמורה תישאר בספרייה.</p>
          <div className="dialog-actions">
            <Button onClick={() => setPanel(null)}>חזרה לאימון</Button>
            <Button
              primary
              icon={Square}
              onClick={() => {
                t.execute("STOP");
                setPanel(null);
              }}
            >
              עצירת אימון
            </Button>
          </div>
        </Overlay>
      )}
      {panel === "library" && (
        <Library
          programs={programs}
          setPrograms={savePrograms}
          active={t.view.workout}
          onClose={() => setPanel(null)}
          onLoad={(p) => {
            if (t.execute("LOAD_WORKOUT", p)) setPanel(null);
          }}
        />
      )}
      {panel === "pair" && (
        <Overlay title="הסטודיו בידיים שלכם" onClose={() => setPanel(null)}>
          <p>
            סרקו בטלפון שמחובר לאותה רשת Wi-Fi. החיבור ידרוש אישור כאן על המסך.
          </p>
          {t.connection === "connected" ? (
            <>
              <div className="qr-block">
                {qr && t.code?.expires > now ? (
                  <img src={qr} alt="קוד QR לחיבור המאמן" />
                ) : (
                  <div className="qr-placeholder">
                    <Smartphone size={48} />
                    <p>קוד החיבור אינו פעיל</p>
                  </div>
                )}
              </div>
              <div className="pair-countdown">
                {t.code?.expires > now
                  ? `הקוד תקף לעוד ${Math.ceil((t.code.expires - now) / 1000)} שניות`
                  : "הפיקו קוד חדש לחיבור"}
              </div>
              <Button icon={RotateCcw} onClick={t.newCode}>
                קוד חדש
              </Button>
              <details>
                <summary>פתיחה ידנית בטלפון</summary>
                <a
                  className="pair-link"
                  href={pairUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  {pairUrl}
                </a>
                {base.includes("localhost") && (
                  <p className="warning">
                    כתובת localhost זמינה במחשב הזה בלבד. בהגדרות בחרו את כתובת
                    הרשת של שירות הסטודיו.
                  </p>
                )}
              </details>
            </>
          ) : (
            <>
              <p className="warning">
                שירות החיבור אינו מחובר. הטיימר ממשיך לעבוד מקומית.
              </p>
              <Button onClick={() => setPanel("settings")}>
                הגדרת כתובת השירות
              </Button>
            </>
          )}
          {t.devices.length > 0 && (
            <div className="devices">
              <h3>מכשירים מורשים</h3>
              {t.devices.map((d) => (
                <div key={d.id}>
                  <span>
                    {d.name} · {d.role === "controller" ? "שליטה" : "צפייה"}
                  </span>
                  <button onClick={() => t.revoke(d.id)}>ביטול הרשאה</button>
                </div>
              ))}
            </div>
          )}
        </Overlay>
      )}
      {panel === "settings" && (
        <Overlay title="הגדרות הסטודיו" onClose={() => setPanel(null)}>
          <Settings
            base={base}
            setBase={(b) => {
              write("hub", b);
              setBase(b);
            }}
            clean={clean}
            setClean={(v) => {
              setClean(v);
              write("clean", v);
            }}
            t={t}
          />
        </Overlay>
      )}
      {t.pending.length > 0 && (
        <Overlay
          title="בקשת חיבור חדשה"
          onClose={() => t.approve(t.pending[0].id, false)}
        >
          <p>
            <strong>{t.pending[0].name}</strong> מבקש להתחבר למסך. אשרו רק מכשיר
            שאתם מזהים.
          </p>
          <div className="dialog-actions">
            <Button onClick={() => t.approve(t.pending[0].id, false)}>
              דחייה
            </Button>
            <Button
              primary
              icon={Check}
              onClick={() => t.approve(t.pending[0].id, true)}
            >
              אישור חיבור
            </Button>
          </div>
        </Overlay>
      )}
    </main>
  );
}
function Settings({ base, setBase, clean, setClean, t }) {
  const [url, setUrl] = useState(base);
  const [err, setErr] = useState("");
  return (
    <div className="settings">
      <label className="toggle-row">
        <span>תצוגה נקייה ללא צילום רקע</span>
        <input
          type="checkbox"
          checked={clean}
          onChange={(e) => setClean(e.target.checked)}
        />
      </label>
      <label className="field">
        עוצמת התראות
        <input
          type="range"
          min="0"
          max="1"
          step=".1"
          value={t.volume}
          onChange={(e) => t.execute("SET_VOLUME", Number(e.target.value))}
        />
      </label>
      <label className="field">
        כתובת שירות הסטודיו
        <input
          dir="ltr"
          value={url}
          placeholder="http://192.168.1.10:4174"
          onChange={(e) => setUrl(e.target.value)}
        />
      </label>
      <p className="muted">
        הכתובת מופיעה במחשב שמפעיל את שירות BareFit. הטלוויזיה והטלפון צריכים
        להיות באותה רשת.
      </p>
      {err && <p className="warning">{err}</p>}
      <Button
        onClick={() => {
          try {
            const u = new URL(url);
            if (!["http:", "https:"].includes(u.protocol)) throw Error();
            setBase(u.origin);
            setErr("");
          } catch {
            setErr("יש להזין כתובת http או https תקינה");
          }
        }}
      >
        שמירת כתובת
      </Button>
      {t.connection === "unauthorized" && (
        <Button onClick={t.resetPairing}>יצירת חיבור מסך חדש</Button>
      )}
      <p className="muted">
        גרסה 0.1 · עבודה מקומית · חיצים לניווט, רווח להתחלה והשהיה
      </p>
    </div>
  );
}
function Library({ programs, setPrograms, active, onClose, onLoad }) {
  const [editing, setEditing] = useState(null),
    [error, setError] = useState("");
  const file = useRef();
  const exportAll = () => {
    const url = URL.createObjectURL(
      new Blob([JSON.stringify({ version: 1, programs }, null, 2)], {
        type: "application/json",
      }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = "barefit-workouts.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const importAll = async (e) => {
    try {
      const f = e.target.files[0];
      if (!f || f.size > 1000000) throw Error("הקובץ גדול מדי");
      const json = JSON.parse(await f.text());
      if (
        json.version !== 1 ||
        !Array.isArray(json.programs) ||
        json.programs.length > 100
      )
        throw Error("קובץ אימונים לא תקין");
      const data = json.programs.map(validateWorkout);
      setPrograms([
        ...programs,
        ...data.map((p) => ({ ...p, id: commandId() })),
      ]);
      setError("");
    } catch (e) {
      setError(e.message);
    }
    e.target.value = "";
  };
  return (
    <Overlay
      title={editing ? "עריכת תוכנית" : "ספריית האימונים"}
      wide
      onClose={onClose}
    >
      {editing ? (
        <WorkoutForm
          workout={editing}
          onCancel={() => setEditing(null)}
          onSave={(w) => {
            setPrograms([...programs.filter((p) => p.id !== w.id), w]);
            setEditing(null);
          }}
        />
      ) : (
        <>
          <div className="library-heading">
            <p>בחרו את הקצב של האימון הבא.</p>
            <Button
              icon={Plus}
              onClick={() =>
                setEditing({
                  ...PRESETS[0],
                  id: commandId(),
                  name: "האימון שלי",
                  kind: "CUSTOM",
                })
              }
            >
              אימון חדש
            </Button>
          </div>
          <div className="program-list">
            {programs.map((p) => (
              <article
                key={p.id}
                className={p.id === active.id ? "selected" : ""}
              >
                <div className="program-kind" dir="ltr">
                  {p.kind}
                </div>
                <div className="program-description">
                  <h3>{p.name}</h3>
                  <p>
                    {p.work} שנ׳ עבודה · {p.rest} שנ׳ מנוחה · {p.rounds} סבבים ·{" "}
                    {p.sets} סטים
                  </p>
                </div>
                <div className="program-actions">
                  <button
                    onClick={() =>
                      setEditing({
                        ...p,
                        id: commandId(),
                        name: p.name + " — העתק",
                      })
                    }
                  >
                    שכפול ועריכה
                  </button>
                  <button
                    className="select-program"
                    onClick={() => onLoad(p)}
                    aria-label={"בחירה: " + p.name}
                  >
                    {p.id === active.id ? (
                      <Check size={18} />
                    ) : (
                      <ArrowLeft size={18} />
                    )}
                  </button>
                </div>
              </article>
            ))}
          </div>
          <div className="library-footer">
            <button onClick={exportAll}>
              <Download size={17} /> ייצוא תוכניות
            </button>
            <button onClick={() => file.current.click()}>
              <Upload size={17} /> ייבוא תוכניות
            </button>
            <input
              ref={file}
              hidden
              type="file"
              accept=".json"
              onChange={importAll}
            />
          </div>
          {error && <p className="warning">{error}</p>}
        </>
      )}
    </Overlay>
  );
}
function WorkoutForm({ workout, onSave, onCancel }) {
  const [w, setW] = useState(workout),
    [err, setErr] = useState("");
  const fields = [
    ["work", "זמן עבודה", 1, 7200],
    ["rest", "זמן מנוחה", 0, 3600],
    ["rounds", "מספר סבבים", 1, 100],
    ["sets", "מספר סטים", 1, 20],
    ["between", "מנוחה בין סטים", 0, 3600],
    ["prepare", "זמן הכנה", 0, 300],
  ];
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        try {
          onSave(validateWorkout(w));
        } catch (e) {
          setErr(e.message);
        }
      }}
    >
      <label className="field">
        שם האימון
        <input
          value={w.name}
          maxLength={80}
          required
          onChange={(e) => setW({ ...w, name: e.target.value })}
        />
      </label>
      <div className="form-grid">
        {fields.map(([key, label, min, max]) => (
          <label className="field" key={key}>
            {label}
            {!["rounds", "sets"].includes(key) && <small>בשניות</small>}
            <input
              type="number"
              min={min}
              max={max}
              step="1"
              required
              value={w[key]}
              onChange={(e) => setW({ ...w, [key]: e.target.value })}
            />
          </label>
        ))}
      </div>
      {err && <p className="warning">{err}</p>}
      <div className="dialog-actions">
        <Button type="button" onClick={onCancel}>
          ביטול
        </Button>
        <Button primary type="submit" icon={Check}>
          שמירת תוכנית
        </Button>
      </div>
    </form>
  );
}
function Coach() {
  const [base] = useBase();
  const [credentials, setCredentials] = useState(() =>
    read("coach:" + base, null),
  );
  const [status, setStatus] = useState("disconnected");
  const [view, setView] = useState(null);
  const [role, setRole] = useState("viewer");
  const [hostOnline, setHostOnline] = useState(false);
  const [error, setError] = useState("");
  const [waiting, setWaiting] = useState(false);
  const [panel, setPanel] = useState(null);
  const [name, setName] = useState("הטלפון שלי");
  const [manualRoom, setManualRoom] = useState(""),
    [manualCode, setManualCode] = useState("");
  const [programs, setPrograms] = useState(() => read("programs", PRESETS));
  const conn = useRef(null);
  const sequence = useRef(read("sequence:" + base, 0));
  const [pending, setPending] = useState(null);
  const hash = new URLSearchParams(location.hash.slice(1));
  const room = hash.get("room") || manualRoom,
    code = hash.get("code") || manualCode;
  useEffect(() => {
    if (!credentials) return;
    const c = new Connection(
      base,
      { ...credentials, role: credentials.pending ? "pending" : "coach" },
      (m) => {
        if (m.type === "authenticated") {
          setRole(m.role);
          sequence.current = Math.max(sequence.current, m.sequence || 0);
          setWaiting(false);
        }
        if (m.type === "waiting") setWaiting(true);
        if (m.type === "paired") {
          const data = { room: credentials.room, token: m.token };
          write("coach:" + base, data);
          setCredentials(data);
          setWaiting(false);
          history.replaceState({}, "", location.pathname + "?mode=coach");
        }
        if (m.type === "rejected") {
          setWaiting(false);
          setCredentials(null);
          setError("בקשת החיבור נדחתה או פגה. סרקו קוד חדש.");
        }
        if (m.type === "host-status") setHostOnline(m.online);
        if (m.type === "state") {
          setView(m.state);
          setHostOnline(true);
        }
        if (m.type === "ack") {
          setPending(null);
          if (!m.ok) setError(m.error);
        }
      },
      (s) => {
        setStatus(s);
        if (s === "unauthorized") {
          write("coach:" + base, null);
          setCredentials(null);
          setWaiting(false);
          setError("החיבור פג. סרקו קוד חדש מהמסך.");
        }
      },
    );
    conn.current = c;
    return () => c.close();
  }, [credentials, base]);
  useEffect(() => {
    if (!pending) return;
    const id = setTimeout(() => {
      setPending(null);
      setError("לא התקבל אישור. בדקו את מצב המסך לפני ניסיון נוסף.");
    }, 6000);
    return () => clearTimeout(id);
  }, [pending]);
  const execute = (type, payload) => {
    if (
      status !== "connected" ||
      !hostOnline ||
      role !== "controller" ||
      pending
    )
      return false;
    const id = commandId();
    sequence.current++;
    write("sequence:" + base, sequence.current);
    if (
      !conn.current.send({
        type: "command",
        id,
        sequence: sequence.current,
        command: type,
        payload,
      })
    ) {
      setError("החיבור נותק");
      return false;
    }
    setPending(id);
    return true;
  };
  const pair = async (e) => {
    e.preventDefault();
    try {
      const data = await request(base, "/api/pair", { room, code, name });
      setCredentials({ ...data, pending: true });
      setError("");
    } catch (e) {
      setError(e.message);
    }
  };
  return (
    <main className="coach">
      <header className="coach-header">
        <Brand small />
        <span>
          <span
            className={
              "status-dot " +
              (status === "connected" && hostOnline ? "online" : "")
            }
          />
          {status === "connected" && hostOnline ? "מחובר למסך" : "לא מחובר"}
        </span>
      </header>
      {!credentials ? (
        <section className="coach-pair">
          <Smartphone size={42} />
          <h1>הסטודיו בידיים שלכם</h1>
          <p>סרקו את קוד ה־QR במסך האימון, או הזינו פרטי חיבור.</p>
          <form onSubmit={pair}>
            <label className="field">
              שם המכשיר
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={60}
                required
              />
            </label>
            {!hash.get("room") && (
              <>
                <label className="field">
                  מזהה מסך
                  <input
                    value={manualRoom}
                    onChange={(e) => setManualRoom(e.target.value)}
                    required
                  />
                </label>
                <label className="field">
                  קוד חיבור
                  <input
                    value={manualCode}
                    onChange={(e) => setManualCode(e.target.value)}
                    required
                  />
                </label>
              </>
            )}
            <Button primary type="submit">
              בקשת חיבור למסך
            </Button>
          </form>
        </section>
      ) : waiting ? (
        <section className="coach-pair">
          <Monitor size={42} />
          <h1>ממתינים לאישור במסך</h1>
          <p>אשרו את {name} בטלוויזיה כדי להתחיל.</p>
        </section>
      ) : view ? (
        <>
          <div className="coach-title">
            <span className="eyebrow">מסך הסטודיו</span>
            <h1>{view.workout.name}</h1>
            <p>{role === "controller" ? "שליטת מאמן" : "צפייה בלבד"}</p>
          </div>
          <TimerFace view={view} compact />
          <fieldset
            disabled={
              role !== "controller" ||
              status !== "connected" ||
              !hostOnline ||
              !!pending
            }
          >
            <Controls
              view={view}
              execute={execute}
              stop={() => setPanel("stop")}
            />
            <div className="coach-extra">
              <Button icon={SkipBack} onClick={() => execute("PREVIOUS_PHASE")}>
                שלב קודם
              </Button>
              <Button icon={BookOpen} onClick={() => setPanel("library")}>
                בחירת אימון
              </Button>
            </div>
          </fieldset>
          <div className="coach-status">
            {pending
              ? "ממתין לאישור הפעולה מהמסך"
              : !hostOnline || status !== "connected"
                ? "החיבור נותק. השעון בטלוויזיה ממשיך לפעול."
                : "השעון מסונכרן עם מסך האימון"}
          </div>
        </>
      ) : (
        <section className="coach-pair">
          <h1>מתחברים למסך…</h1>
          <p>ודאו שהמסך פתוח ומחובר לרשת.</p>
        </section>
      )}
      {error && (
        <div className="inline-error" role="alert">
          {error}
          <button onClick={() => setError("")} aria-label="סגירת שגיאה">
            <X size={18} />
          </button>
        </div>
      )}
      {panel === "stop" && (
        <Overlay title="לעצור את האימון?" onClose={() => setPanel(null)}>
          <p>השעון בטלוויזיה יחזור להתחלה.</p>
          <Button
            primary
            onClick={() => {
              execute("STOP");
              setPanel(null);
            }}
          >
            עצירת אימון
          </Button>
        </Overlay>
      )}
      {panel === "library" && (
        <Library
          active={view.workout}
          programs={programs}
          setPrograms={(p) => {
            setPrograms(p);
            write("programs", p);
          }}
          onClose={() => setPanel(null)}
          onLoad={(p) => {
            execute("LOAD_WORKOUT", p);
            setPanel(null);
          }}
        />
      )}
      <footer className="coach-footer">BAREFIT · STRONGER TOGETHER</footer>
    </main>
  );
}
