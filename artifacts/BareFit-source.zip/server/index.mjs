import { createHub } from "./hub.mjs";
import { networkInterfaces } from "node:os";
const port = Number(process.env.PORT || 4174);
const addresses = Object.values(networkInterfaces())
  .flat()
  .filter((a) => a.family === "IPv4" && !a.internal)
  .map((a) => a.address);
const hub = await createHub({
  allowOrigins: [
    "http://localhost:4173",
    "http://127.0.0.1:4173",
    `http://localhost:${port}`,
    `http://127.0.0.1:${port}`,
    ...addresses.flatMap((a) => [`http://${a}:4173`, `http://${a}:${port}`]),
    ...(process.env.ALLOW_ORIGINS || "").split(",").filter(Boolean),
  ],
});
hub.server.listen(port, "0.0.0.0", () => {
  console.log(`BareFit: http://localhost:${port}`);
  addresses.forEach((a) => console.log(`Studio network: http://${a}:${port}`));
});
process.on("SIGINT", async () => {
  await hub.close();
  process.exit(0);
});
