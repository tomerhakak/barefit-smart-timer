# Verification — 23 October 2026

## Passed

- 13 automated tests: monotonic catch-up over missed callbacks; millisecond pause/resume; final round and set transitions; finish/restart; safe paused recovery; invalid settings/snapshots; manual phase navigation; running-workout mutation rejection; custom sequences; boundary formatting; 24-hour simulated reference-clock comparison; pairing approval, single controller/viewer permissions, duplicate/out-of-order command rejection, reconnect and revocation; cross-origin request rejection.
- Web production build with modern and legacy JavaScript bundles and locally bundled assets/fonts.
- Native TypeScript check.
- Hermes JavaScript bundle export for Android and iOS using React Native TV. This verifies module resolution and bundle generation, not iOS/tvOS compilation or device operation.
- Android TV release-variant APK build, API 24 minimum, API 36 target, ARM64/ARMv7/x86/x86_64. Uses a development signing key. APK contains JavaScript, fonts and background assets and TV launcher metadata/banner.
- Separate Android phone release-variant APK build with package `com.barefit.timer` and unspecified orientation. Uses the same shared core and includes both controller and local-timer modes. Also development-signed; not physically device-tested.
- LG webOS IPK packaging with the official `@webos-tools/cli`.
- Browser UI verification: actual start/pause; QR and one-time connection request; approval on display; controller receives current state; remote next-phase changes both screens; refresh while running restores paused state with time preserved.
- Visual inspection of main display and a 390 × 844 CSS-pixel phone viewport. Screenshots are in `artifacts/`.

## Not yet verified / release work

- No physical Android TV, Apple TV, Samsung, LG, iPhone or Android phone was tested. No hardware-level stability or timing guarantee is claimed.
- iOS/tvOS native compilation and signing require macOS, Xcode and an appropriate signing identity. Windows prebuild explicitly refused the iOS native target. No IPA is supplied.
- Samsung source package requires Tizen Studio, a Samsung signing certificate, WGT build and testing on a specific TV. No signed WGT is supplied.
- Android APKs are for internal testing, signed with a development key. Store release signing, app-store review and installed-device validation are outstanding.
- Production TLS, credential storage hardening, real network latency measurements, physical 8/24-hour endurance and studio readability tests remain release acceptance work.
- Native program import/export and a visual complex-sequence editor are not yet implemented; Web supports JSON import/export and the shared engine supports custom sequences.

The bundled source intentionally excludes local pairing credentials and build-network workarounds. A temporary per-process DNS/CONNECT workaround was used during dependency downloads; it did not change OS DNS or disable certificate validation.
