import test from "node:test";
import assert from "node:assert/strict";
import { WebSocket } from "ws";
import { createHub } from "../server/hub.mjs";
function inbox(ws) {
  const queue = [],
    waiters = [];
  ws.on("message", (raw) => {
    const m = JSON.parse(raw);
    const i = waiters.findIndex((w) => w.type === m.type);
    if (i >= 0) {
      const [w] = waiters.splice(i, 1);
      clearTimeout(w.timer);
      w.resolve(m);
    } else queue.push(m);
  });
  return (type) => {
    const i = queue.findIndex((m) => m.type === type);
    if (i >= 0) return Promise.resolve(queue.splice(i, 1)[0]);
    return new Promise((resolve, reject) => {
      const w = {
        type,
        resolve,
        timer: setTimeout(() => reject(Error("No message: " + type)), 3000),
      };
      waiters.push(w);
    });
  };
}
test("pair approval, control ownership, replay protection, reconnect and revoke", async (t) => {
  const hub = await createHub({ persist: false });
  await new Promise((r) => hub.server.listen(0, "127.0.0.1", r));
  t.after(() => hub.close());
  const base = `http://127.0.0.1:${hub.server.address().port}`;
  const post = async (url, data) => {
    const r = await fetch(base + url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    return { status: r.status, data: await r.json() };
  };
  const open = async (auth) => {
    const ws = new WebSocket(base.replace("http", "ws") + "/socket");
    const next = inbox(ws);
    await new Promise((r) => ws.once("open", r));
    ws.send(JSON.stringify({ type: "auth", ...auth }));
    return { ws, next, send: (m) => ws.send(JSON.stringify(m)) };
  };
  const { data: credentials } = await post("/api/rooms", {});
  const host = await open({ ...credentials, role: "host" });
  await host.next("authenticated");
  assert.equal(
    (await post("/api/pair", { room: credentials.room, code: "wrong" })).status,
    400,
  );
  async function pair(name) {
    host.send({ type: "new-code" });
    const code = await host.next("pair-code");
    const { data } = await post("/api/pair", {
      room: credentials.room,
      code: code.code,
      name,
    });
    assert.equal(
      (
        await post("/api/pair", {
          room: credentials.room,
          code: code.code,
          name,
        })
      ).status,
      400,
    );
    const pending = await open({ ...data, role: "pending" });
    await pending.next("waiting");
    const req = await host.next("pair-request");
    host.send({ type: "approve", id: req.id });
    const paired = await pending.next("paired");
    return {
      token: paired.token,
      room: credentials.room,
      role: "coach",
      expectedRole: paired.role,
      id: req.id,
    };
  }
  const auth = await pair("Coach");
  const coach = await open(auth);
  assert.equal((await coach.next("authenticated")).role, "controller");
  coach.send({ type: "command", id: "c1", sequence: 1, command: "START" });
  assert.equal((await host.next("command")).command, "START");
  host.send({ type: "ack", id: "c1", ok: true });
  assert.equal((await coach.next("ack")).ok, true);
  coach.send({ type: "command", id: "c1", sequence: 1, command: "START" });
  assert.equal((await coach.next("ack")).ok, true);
  coach.send({ type: "command", id: "c2", sequence: 1, command: "NEXT_PHASE" });
  assert.equal((await coach.next("ack")).ok, false);
  const second = await pair("Viewer");
  const viewer = await open(second);
  assert.equal((await viewer.next("authenticated")).role, "viewer");
  viewer.send({ type: "command", id: "v1", sequence: 1, command: "STOP" });
  assert.equal((await viewer.next("ack")).ok, false);
  host.send({ type: "state", state: { remaining: 43210, status: "running" } });
  assert.equal((await coach.next("state")).state.remaining, 43210);
  coach.ws.close();
  const reconnect = await open(auth);
  assert.equal((await reconnect.next("authenticated")).sequence, 1);
  assert.equal((await reconnect.next("state")).state.remaining, 43210);
  host.send({ type: "revoke", id: auth.id });
  const close = await new Promise((r) =>
    reconnect.ws.once("close", (code) => r(code)),
  );
  assert.equal(close, 1008);
});
test("foreign browser origins are rejected", async (t) => {
  const hub = await createHub({ persist: false });
  await new Promise((r) => hub.server.listen(0, "127.0.0.1", r));
  t.after(() => hub.close());
  const r = await fetch(
    `http://127.0.0.1:${hub.server.address().port}/api/rooms`,
    {
      method: "POST",
      headers: {
        origin: "https://evil.example",
        "content-type": "application/json",
      },
      body: "{}",
    },
  );
  assert.equal(r.status, 403);
});
