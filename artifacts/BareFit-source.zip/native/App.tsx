import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  ImageBackground,
  TextInput,
  ScrollView,
  Modal,
  Platform,
  Alert,
  AppState,
  useWindowDimensions,
} from "react-native";
import Svg, { Circle } from "react-native-svg";
import QRCode from "react-native-qrcode-svg";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useFonts } from "expo-font";
import { useKeepAwake } from "expo-keep-awake";
import { useAudioPlayer } from "expo-audio";
import {
  WorkoutEngine,
  PRESETS,
  LABELS,
  formatTime,
  validateWorkout,
} from "../shared/engine.mjs";
import { Connection, request, commandId } from "../shared/connection.mjs";
const lime = "#b4ff00";
const colors = {
  ready: lime,
  work: lime,
  prepare: "#57b7ff",
  rest: "#ffb146",
  between: "#ffb146",
  finished: lime,
};
const load = async (k, f = null) => {
  try {
    return JSON.parse(await AsyncStorage.getItem(k)) ?? f;
  } catch {
    return f;
  }
};
let writes = Promise.resolve();
const save = (k, v) => {
  const data = JSON.stringify(v);
  writes = writes.catch(() => {}).then(() => AsyncStorage.setItem(k, data));
  return writes;
};
function Action({ children, onPress, primary = false, disabled = false }: any) {
  const [focus, setFocus] = useState(false);
  return (
    <Pressable
      accessibilityRole="button"
      onFocus={() => setFocus(true)}
      onBlur={() => setFocus(false)}
      onPress={onPress}
      disabled={disabled}
      style={[
        s.button,
        primary && s.primary,
        focus && s.focus,
        disabled && { opacity: 0.35 },
      ]}
    >
      <Text style={[s.buttonText, primary && { color: "#111807" }]}>
        {children}
      </Text>
    </Pressable>
  );
}
function Face({ view, size }: any) {
  const c = colors[view.phase] || lime;
  return (
    <View
      style={{
        width: size,
        height: size,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#040800ed",
        borderRadius: size / 2,
      }}
    >
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={size * 0.48}
          stroke={c}
          strokeWidth={1}
          fill="none"
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={size * 0.45}
          stroke="#28311c"
          strokeWidth={size * 0.042}
          fill="none"
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={size * 0.45}
          stroke={c}
          strokeWidth={size * 0.042}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={[
            Math.PI *
              size *
              0.9 *
              (view.status === "ready" ? 1 : view.progress),
            Math.PI * size * 0.9,
          ]}
          rotation={-90}
          origin={`${size / 2},${size / 2}`}
        />
      </Svg>
      <Text
        style={{
          fontFamily: "Heebo",
          fontWeight: "900",
          fontSize: size * 0.12,
          color: c,
        }}
      >
        {view.status === "paused" ? "השהיה" : view.label || LABELS[view.phase]}
      </Text>
      <Text
        style={{
          fontFamily: "Anton",
          fontSize: size * 0.29,
          color: "white",
          lineHeight: size * 0.36,
        }}
      >
        {view.status === "finished"
          ? "✓"
          : formatTime(
              view.status === "ready"
                ? view.workout.work * 1000
                : view.remaining,
            )}
      </Text>
      <View
        style={{
          width: size * 0.24,
          height: size * 0.24,
          borderRadius: size * 0.12,
          borderColor: c,
          borderWidth: 2,
          alignItems: "center",
          justifyContent: "center",
          marginTop: 8,
        }}
      >
        <Text
          style={{
            color: "white",
            fontFamily: "Heebo",
            fontSize: size * 0.036,
          }}
        >
          סבב
        </Text>
        <Text
          style={{
            color: "white",
            fontFamily: "Anton",
            fontSize: size * 0.083,
          }}
        >
          {view.round}/{view.workout.rounds}
        </Text>
      </View>
      <Text style={{ color: "#b3bca6", fontSize: size * 0.023, marginTop: 10 }}>
        סט {view.set} מתוך {view.workout.sets}
      </Text>
    </View>
  );
}
export default function App() {
  useKeepAwake();
  const [fonts] = useFonts({
    Anton: require("../public/assets/Anton-Regular.ttf"),
    Heebo: require("../public/assets/Heebo.ttf"),
  });
  const { width, height } = useWindowDimensions();
  const isTV = Platform.isTV;
  const [ready, setReady] = useState(false),
    [mode, setMode] = useState(isTV ? "display" : "coach"),
    [base, setBase] = useState(""),
    [draftBase, setDraftBase] = useState(""),
    [view, setView] = useState(null),
    [remoteView, setRemoteView] = useState(null),
    [status, setStatus] = useState("disconnected"),
    [role, setRole] = useState("viewer"),
    [hostOnline, setHostOnline] = useState(false),
    [code, setCode] = useState(null),
    [pendingPair, setPendingPair] = useState(null),
    [panel, setPanel] = useState(null),
    [error, setError] = useState(""),
    [programs, setPrograms] = useState(PRESETS),
    [workout, setWorkout] = useState(null),
    [muted, setMuted] = useState(false),
    [room, setRoom] = useState(""),
    [pairCode, setPairCode] = useState(""),
    [creds, setCreds] = useState(null),
    [waiting, setWaiting] = useState(false),
    [pendingCommand, setPendingCommand] = useState(null),
    [devices, setDevices] = useState([]);
  const engine = useRef(new WorkoutEngine()),
    connection = useRef(null),
    sequence = useRef(0),
    processed = useRef([]),
    mutedRef = useRef(false);
  mutedRef.current = muted;
  const player = useAudioPlayer(require("../public/assets/beep.wav"));
  const lastSound = useRef("");
  const size = Math.min(
    isTV ? height * 0.62 : width * 0.88,
    isTV ? width * 0.52 : 450,
  );
  const persist = () =>
    save("session", {
      ...engine.current.snapshot(),
      processed: processed.current,
    });
  const execute = async (type, payload?, remote = false) => {
    try {
      if (type === "SET_VOLUME") {
        const n = Number(payload);
        if (!Number.isFinite(n) || n < 0 || n > 1)
          throw Error("עוצמה לא תקינה");
        player.volume = n;
        await save("volume", n);
      } else engine.current.command(type, payload);
      setView(engine.current.view());
      if (!remote) await persist();
      connection.current?.send({ type: "state", state: engine.current.view() });
      return true;
    } catch (e) {
      setError(e.message);
      return false;
    }
  };
  const execRef = useRef(execute);
  execRef.current = execute;
  useEffect(() => {
    let disposed = false;
    (async () => {
      const [saved, hub, library, volume] = await Promise.all([
        load("session"),
        load("hub", ""),
        load("programs", PRESETS),
        load("volume", 0.6),
      ]);
      if (disposed) return;
      if (saved)
        try {
          engine.current.restore(saved);
          processed.current = saved.processed || [];
        } catch {
          setError("השמירה לא תקינה. הטיימר אופס.");
        }
      player.volume = volume;
      setBase(hub);
      setDraftBase(hub);
      setPrograms(library);
      setView(engine.current.view());
      setReady(true);
    })();
    return () => {
      disposed = true;
    };
  }, []);
  useEffect(() => {
    if (!ready) return;
    let n = 0,
      revision = -1;
    const timer = setInterval(() => {
      const v = engine.current.view();
      setView(v);
      if (mode === "display") {
        if (++n % 3 === 0)
          connection.current?.send({ type: "state", state: v });
        if (n % 10 === 0 || v.revision !== revision) {
          revision = v.revision;
          persist().catch(() => setError("לא ניתן לשמור את מצב האימון"));
        }
        const sec = Math.ceil(v.remaining / 1000),
          key = `${v.index}:${sec}:${v.status}`;
        if (
          !mutedRef.current &&
          lastSound.current !== key &&
          ((v.status === "running" && sec <= 3) || v.status === "finished")
        ) {
          try {
            player.seekTo(0);
            player.play();
          } catch {}
        }
        lastSound.current = key;
      }
    }, 100);
    const sub = AppState.addEventListener("change", (state) => {
      if (state !== "active") persist().catch(() => {});
    });
    return () => {
      clearInterval(timer);
      sub.remove();
    };
  }, [ready, mode]);
  useEffect(() => {
    if (!ready || !base || mode !== "display") return;
    let cancelled = false,
      c;
    (async () => {
      try {
        let credentials = await load("host:" + base);
        if (!credentials) {
          credentials = await request(base, "/api/rooms", {});
          await save("host:" + base, credentials);
        }
        if (cancelled) return;
        c = new Connection(
          base,
          { ...credentials, role: "host" },
          async (m) => {
            if (m.type === "authenticated") {
              setDevices(m.devices || []);
              c.send({ type: "state", state: engine.current.view() });
            }
            if (m.type === "pair-code") setCode(m);
            if (m.type === "pair-request") {
              setCode(null);
              setPendingPair(m);
            }
            if (m.type === "devices") setDevices(m.devices);
            if (m.type === "command") {
              let ack = processed.current.find((a) => a.id === m.id);
              if (!ack) {
                const ok = await execRef.current(m.command, m.payload, true);
                ack = {
                  type: "ack",
                  id: m.id,
                  ok,
                  error: ok ? "" : "הפקודה לא בוצעה",
                };
                processed.current = [...processed.current, ack].slice(-500);
                try {
                  await persist();
                } catch {
                  ack.ok = false;
                  ack.error = "הפעולה בוצעה אך שמירת המצב נכשלה";
                }
              }
              c.send(ack);
            }
            if (m.type === "error") setError(m.error);
          },
          setStatus,
        );
        connection.current = c;
      } catch {
        setError("שירות הסטודיו לא זמין. הטיימר עובד מקומית.");
      }
    })();
    return () => {
      cancelled = true;
      c?.close();
      connection.current = null;
    };
  }, [ready, base, mode]);
  useEffect(() => {
    if (mode !== "coach" || !base) return;
    let disposed = false;
    load("coach:" + base).then((c) => {
      if (!disposed) setCreds(c);
    });
    return () => {
      disposed = true;
    };
  }, [base, mode]);
  useEffect(() => {
    if (!creds || mode !== "coach") return;
    const c = new Connection(
      base,
      { ...creds, role: creds.pending ? "pending" : "coach" },
      (m) => {
        if (m.type === "waiting") setWaiting(true);
        if (m.type === "paired") {
          const next = { room: creds.room, token: m.token };
          save("coach:" + base, next);
          setCreds(next);
          setWaiting(false);
        }
        if (m.type === "authenticated") {
          setRole(m.role);
          sequence.current = m.sequence || 0;
        }
        if (m.type === "state") {
          setRemoteView(m.state);
          setHostOnline(true);
        }
        if (m.type === "host-status") setHostOnline(m.online);
        if (m.type === "rejected") {
          setWaiting(false);
          setCreds(null);
          setError("בקשת החיבור נדחתה או פגה");
        }
        if (m.type === "ack") {
          setPendingCommand(null);
          if (!m.ok) setError(m.error);
        }
      },
      (value) => {
        setStatus(value);
        if (value === "unauthorized") {
          save("coach:" + base, null);
          setCreds(null);
          setError("יש להתחבר מחדש למסך");
        }
      },
    );
    connection.current = c;
    return () => {
      c.close();
      connection.current = null;
    };
  }, [creds, mode, base]);
  useEffect(() => {
    if (!pendingCommand) return;
    const id = setTimeout(() => {
      setPendingCommand(null);
      setError("לא התקבל אישור. בדקו את המסך לפני ניסיון נוסף.");
    }, 6000);
    return () => clearTimeout(id);
  }, [pendingCommand]);
  const send = (type, payload?) => {
    if (mode === "display") return execute(type, payload);
    if (
      status !== "connected" ||
      !hostOnline ||
      role !== "controller" ||
      pendingCommand
    )
      return;
    const id = commandId();
    if (
      connection.current?.send({
        type: "command",
        id,
        sequence: ++sequence.current,
        command: type,
        payload,
      })
    )
      setPendingCommand(id);
  };
  const shown = mode === "display" ? view : remoteView;
  const editable =
    mode === "display" ||
    (role === "controller" &&
      status === "connected" &&
      hostOnline &&
      !pendingCommand);
  const stop = () =>
    Alert.alert("לעצור את האימון?", "השעון יחזור להתחלה.", [
      { text: "ביטול", style: "cancel" },
      {
        text: "עצירת אימון",
        style: "destructive",
        onPress: () => send("STOP"),
      },
    ]);
  const approve = (ok) => {
    connection.current?.send({
      type: ok ? "approve" : "reject",
      id: pendingPair.id,
    });
    setPendingPair(null);
  };
  if (!ready || !fonts)
    return (
      <View style={s.root}>
        <Text style={s.title}>BareFit</Text>
        <Text style={s.text}>טוען את הסטודיו…</Text>
      </View>
    );
  return (
    <ImageBackground
      source={require("../public/assets/gym.png")}
      resizeMode="cover"
      style={s.root}
    >
      <View style={s.shade} />
      <View style={[s.header, { paddingHorizontal: isTV ? 40 : 20 }]}>
        <Text style={[s.brand, { fontSize: isTV ? 50 : 34 }]}>
          Barefit<Text style={{ color: lime }}> /</Text>
        </Text>
        <View style={s.row}>
          <Action onPress={() => setPanel("settings")}>הגדרות</Action>
          {isTV && <Action onPress={() => setPanel("library")}>אימונים</Action>}
          {isTV && (
            <Action onPress={() => send("PREVIOUS_PHASE")}>שלב קודם</Action>
          )}
          {!isTV && (
            <Action
              onPress={() => {
                setMode(mode === "display" ? "coach" : "display");
                setRemoteView(null);
              }}
            >
              {" "}
              {mode === "display" ? "שליטה במסך" : "אימון במכשיר"}
            </Action>
          )}
          <Action
            onPress={() => {
              setPanel("pair");
              connection.current?.send({ type: "new-code" });
            }}
          >
            {mode === "display" ? "חיבור מאמן" : "חיבור למסך"}
          </Action>
        </View>
      </View>
      <ScrollView
        contentContainerStyle={{
          flexGrow: 1,
          alignItems: "center",
          justifyContent: "center",
          paddingBottom: 20,
        }}
      >
        {shown ? (
          <>
            <Text style={s.workoutTitle}>{shown.workout.name}</Text>
            <Face view={shown} size={size} />
            <View style={[s.row, { marginTop: 14 }]}>
              <Action disabled={!editable} onPress={() => send("NEXT_PHASE")}>
                דלג קדימה
              </Action>
              <Action
                primary
                disabled={!editable}
                onPress={() =>
                  send(shown.status === "running" ? "PAUSE" : "START")
                }
              >
                {shown.status === "running"
                  ? "השהיה"
                  : shown.status === "paused"
                    ? "המשך"
                    : "התחל אימון"}
              </Action>
              <Action
                disabled={!editable || shown.status === "ready"}
                onPress={stop}
              >
                עצור
              </Action>
            </View>
            {!isTV && (
              <View style={[s.row, { marginTop: 12 }]}>
                <Action
                  disabled={!editable}
                  onPress={() => send("PREVIOUS_PHASE")}
                >
                  שלב קודם
                </Action>
                <Action
                  disabled={!editable}
                  onPress={() => setPanel("library")}
                >
                  ספריית אימונים
                </Action>
                <Action onPress={() => setMuted(!muted)}>
                  {muted ? "צליל כבוי" : "צליל פעיל"}
                </Action>
              </View>
            )}
            <Text style={s.caption}>
              {mode === "display"
                ? "השעון פועל מקומית"
                : pendingCommand
                  ? "ממתין לאישור מהמסך"
                  : hostOnline
                    ? "מסונכרן עם המסך"
                    : "המסך אינו מחובר"}
            </Text>
          </>
        ) : (
          <View style={s.welcome}>
            <Text style={s.title}>
              {waiting ? "ממתינים לאישור בטלוויזיה" : "הסטודיו בידיים שלכם"}
            </Text>
            <Text style={s.text}>
              חברו את הטלפון למסך האימון דרך הרשת המקומית.
            </Text>
            <Action primary onPress={() => setPanel("pair")}>
              חיבור למסך
            </Action>
          </View>
        )}
      </ScrollView>
      {!!error && (
        <Pressable onPress={() => setError("")} style={s.toast}>
          <Text style={s.text}>{error} ×</Text>
        </Pressable>
      )}
      <Modal
        visible={!!panel || !!pendingPair}
        transparent
        onRequestClose={() => (pendingPair ? approve(false) : setPanel(null))}
      >
        <View style={s.scrim}>
          <View
            style={[
              s.panel,
              {
                width: isTV ? 600 : Math.min(width - 32, 600),
                maxHeight: height * 0.9,
              },
            ]}
          >
            <ScrollView>
              <View style={[s.row, { justifyContent: "space-between" }]}>
                <Text style={s.title}>
                  {pendingPair
                    ? "בקשת חיבור חדשה"
                    : panel === "library"
                      ? "ספריית אימונים"
                      : panel === "settings"
                        ? "הגדרות הסטודיו"
                        : panel === "edit"
                          ? "תוכנית אימון"
                          : "חיבור מקומי"}
                </Text>
                <Action
                  onPress={() =>
                    pendingPair ? approve(false) : setPanel(null)
                  }
                >
                  ×
                </Action>
              </View>
              {pendingPair ? (
                <>
                  <Text style={s.text}>
                    {pendingPair.name} מבקש להתחבר למסך.
                  </Text>
                  <View style={s.row}>
                    <Action onPress={() => approve(false)}>דחייה</Action>
                    <Action primary onPress={() => approve(true)}>
                      אישור
                    </Action>
                  </View>
                </>
              ) : panel === "settings" ? (
                <>
                  <Text style={s.text}>כתובת שירות הסטודיו</Text>
                  <TextInput
                    style={s.input}
                    value={draftBase}
                    onChangeText={setDraftBase}
                    autoCapitalize="none"
                    placeholder="http://192.168.1.10:4174"
                    placeholderTextColor="#888"
                  />
                  <Action
                    primary
                    onPress={() => {
                      try {
                        const u = new URL(draftBase);
                        if (!["http:", "https:"].includes(u.protocol))
                          throw Error();
                        setBase(u.origin);
                        save("hub", u.origin);
                        setPanel(null);
                      } catch {
                        setError("כתובת שירות אינה תקינה");
                      }
                    }}
                  >
                    שמירת כתובת
                  </Action>
                  <Text style={s.caption}>
                    שירות הסטודיו מעביר פקודות בלבד. שעון האימון ממשיך לפעול גם
                    כשהחיבור מתנתק.
                  </Text>
                  {status === "unauthorized" && mode === "display" && (
                    <Action
                      onPress={async () => {
                        await AsyncStorage.removeItem("host:" + base);
                        const old = base;
                        setBase("");
                        setTimeout(() => setBase(old), 100);
                      }}
                    >
                      איפוס חיבור המסך
                    </Action>
                  )}
                </>
              ) : panel === "pair" ? (
                mode === "display" ? (
                  <>
                    <Text style={s.text}>
                      סרקו בטלפון. נדרש אישור במסך לאחר הסריקה.
                    </Text>
                    {code && code.expires > Date.now() ? (
                      <View style={{ alignItems: "center", padding: 20 }}>
                        <QRCode
                          value={`${base}/?mode=coach#room=${code.room}&code=${code.code}`}
                          size={220}
                        />
                        <Text style={s.text}>מזהה מסך: {code.room}</Text>
                        <Text style={s.text}>קוד: {code.code}</Text>
                      </View>
                    ) : (
                      <Text style={s.text}>
                        אין קוד פעיל. ודאו שכתובת השירות הוגדרה.
                      </Text>
                    )}
                    <Action
                      onPress={() =>
                        connection.current?.send({ type: "new-code" })
                      }
                    >
                      קוד חדש
                    </Action>
                    {devices.map((d) => (
                      <View key={d.id} style={s.row}>
                        <Text style={s.text}>
                          {d.name} ·{" "}
                          {d.role === "controller" ? "שליטה" : "צפייה"}
                        </Text>
                        <Action
                          onPress={() =>
                            connection.current?.send({
                              type: "revoke",
                              id: d.id,
                            })
                          }
                        >
                          ביטול הרשאה
                        </Action>
                      </View>
                    ))}
                  </>
                ) : (
                  <>
                    <Text style={s.text}>
                      כתובת השירות: {base || "טרם הוגדרה"}
                    </Text>
                    <TextInput
                      style={s.input}
                      value={room}
                      onChangeText={setRoom}
                      autoCapitalize="none"
                      placeholder="מזהה מסך"
                      placeholderTextColor="#999"
                    />
                    <TextInput
                      style={s.input}
                      value={pairCode}
                      onChangeText={setPairCode}
                      autoCapitalize="none"
                      placeholder="קוד חיבור"
                      placeholderTextColor="#999"
                    />
                    <Action
                      primary
                      onPress={async () => {
                        try {
                          const data = await request(base, "/api/pair", {
                            room,
                            code: pairCode,
                            name:
                              Platform.OS === "ios"
                                ? "iPhone / iPad"
                                : "Android",
                          });
                          setCreds({ ...data, pending: true });
                          setWaiting(true);
                          setPanel(null);
                        } catch (e) {
                          setError(e.message);
                        }
                      }}
                    >
                      בקשת חיבור
                    </Action>
                  </>
                )
              ) : panel === "library" ? (
                <>
                  <Action
                    primary
                    onPress={() => {
                      setWorkout({
                        ...PRESETS[0],
                        id: commandId(),
                        name: "האימון שלי",
                      });
                      setPanel("edit");
                    }}
                  >
                    אימון חדש
                  </Action>
                  {programs.map((p) => (
                    <View key={p.id} style={s.program}>
                      <Text style={s.workoutTitle}>{p.name}</Text>
                      <Text style={s.text}>
                        {p.work} שניות · {p.rest} מנוחה · {p.rounds} סבבים
                      </Text>
                      <View style={s.row}>
                        <Action
                          primary
                          onPress={() => {
                            send("LOAD_WORKOUT", p);
                            setPanel(null);
                          }}
                        >
                          בחירה
                        </Action>
                        <Action
                          onPress={() => {
                            setWorkout({ ...p, id: commandId() });
                            setPanel("edit");
                          }}
                        >
                          שכפול ועריכה
                        </Action>
                      </View>
                    </View>
                  ))}
                </>
              ) : panel === "edit" && workout ? (
                <>
                  <TextInput
                    style={s.input}
                    value={workout.name}
                    onChangeText={(name) => setWorkout({ ...workout, name })}
                  />
                  {[
                    ["work", "עבודה"],
                    ["rest", "מנוחה"],
                    ["rounds", "סבבים"],
                    ["sets", "סטים"],
                    ["between", "מנוחה בין סטים"],
                    ["prepare", "הכנה"],
                  ].map(([key, label]) => (
                    <View key={key}>
                      <Text style={s.text}>{label}</Text>
                      <TextInput
                        style={s.input}
                        keyboardType="number-pad"
                        value={String(workout[key])}
                        onChangeText={(v) =>
                          setWorkout({ ...workout, [key]: v })
                        }
                      />
                    </View>
                  ))}
                  <Action
                    primary
                    onPress={() => {
                      try {
                        const w = validateWorkout(workout);
                        const list = [...programs, w];
                        save("programs", list);
                        setPrograms(list);
                        setPanel("library");
                      } catch (e) {
                        setError(e.message);
                      }
                    }}
                  >
                    שמירת תוכנית
                  </Action>
                </>
              ) : null}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ImageBackground>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#070b04" },
  shade: { ...StyleSheet.absoluteFillObject, backgroundColor: "#0007" },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingTop: 28,
    paddingBottom: 12,
    flexWrap: "wrap",
  },
  brand: { fontFamily: "Anton", color: "white" },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    justifyContent: "center",
    flexWrap: "wrap",
  },
  button: {
    borderWidth: 1,
    borderColor: "#727e61",
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 20,
    backgroundColor: "#11190de8",
    minWidth: 70,
    marginVertical: 4,
  },
  primary: { backgroundColor: lime, borderColor: lime },
  focus: { borderColor: "white", borderWidth: 3, transform: [{ scale: 1.04 }] },
  buttonText: {
    color: "white",
    fontFamily: "Heebo",
    fontWeight: "700",
    fontSize: 18,
    textAlign: "center",
  },
  title: {
    fontFamily: "Heebo",
    color: "white",
    fontSize: 24,
    fontWeight: "700",
    textAlign: "right",
    marginVertical: 14,
  },
  text: {
    fontFamily: "Heebo",
    color: "#d3dcc8",
    fontSize: 16,
    textAlign: "right",
    lineHeight: 26,
    marginVertical: 8,
  },
  caption: {
    fontFamily: "Heebo",
    color: "#bdc7ae",
    fontSize: 12,
    textAlign: "center",
    marginTop: 16,
  },
  workoutTitle: {
    fontFamily: "Heebo",
    color: "white",
    fontSize: 21,
    fontWeight: "700",
    textAlign: "right",
    marginVertical: 12,
  },
  welcome: { padding: 25, maxWidth: 450 },
  scrim: {
    flex: 1,
    backgroundColor: "#000c",
    alignItems: "center",
    justifyContent: "center",
  },
  panel: {
    backgroundColor: "#151c0f",
    borderColor: "#53643d",
    borderWidth: 1,
    borderRadius: 18,
    padding: 25,
  },
  input: {
    borderWidth: 1,
    borderColor: "#53643d",
    backgroundColor: "#090e06",
    borderRadius: 8,
    color: "white",
    fontSize: 18,
    padding: 14,
    marginVertical: 10,
    textAlign: "right",
  },
  program: { borderTopWidth: 1, borderColor: "#354328", paddingVertical: 16 },
  toast: {
    position: "absolute",
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: "#493b1b",
    borderRadius: 8,
    padding: 12,
  },
});
