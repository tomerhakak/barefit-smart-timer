const isTV = process.env.EXPO_TV === "1";
module.exports = {
  expo: {
    name: "BareFit",
    slug: "barefit",
    version: "0.1.0",
    orientation: isTV ? "landscape" : "default",
    userInterfaceStyle: "dark",
    icon: "../public/icon.png",
    assetBundlePatterns: ["**/*"],
    ios: {
      bundleIdentifier: isTV ? "com.barefit.timer.tv" : "com.barefit.timer",
      supportsTablet: true,
      infoPlist: {
        NSLocalNetworkUsageDescription:
          "BareFit מתחבר למסך ולמאמן ברשת המקומית של הסטודיו.",
        NSAppTransportSecurity: { NSAllowsLocalNetworking: true },
      },
    },
    android: {
      package: isTV ? "com.barefit.timer.tv" : "com.barefit.timer",
      permissions: ["INTERNET", "ACCESS_NETWORK_STATE", "WAKE_LOCK"],
    },
    plugins: [
      ["@react-native-tvos/config-tv", { isTV, androidTVBanner: "../public/tv-banner.png" }],
      [
        "expo-font",
        {
          fonts: [
            "../public/assets/Anton-Regular.ttf",
            "../public/assets/Heebo.ttf",
          ],
        },
      ],
      "./plugins/local-network.js",
    ],
  },
};
