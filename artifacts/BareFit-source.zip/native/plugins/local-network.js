const { withAndroidManifest } = require("expo/config-plugins");
// Studio LAN transport. Deploy with trusted TLS when operating on untrusted Wi-Fi.
module.exports = (config) =>
  withAndroidManifest(config, (c) => {
    c.modResults.manifest.application[0].$["android:usesCleartextTraffic"] =
      "true";
    return c;
  });
